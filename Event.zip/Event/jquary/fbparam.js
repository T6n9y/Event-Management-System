var FBRESA = "http://www.fastbookings.biz/DIRECTORY/";
var FB_nb_day_delay = 7;
var FB_useGoogleAnalytics = false;